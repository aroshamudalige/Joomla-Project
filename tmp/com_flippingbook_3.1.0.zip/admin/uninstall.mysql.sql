DROP TABLE IF EXISTS `#__flippingbook_books`;
DROP TABLE IF EXISTS `#__flippingbook_categories`;
DROP TABLE IF EXISTS `#__flippingbook_config`;
DROP TABLE IF EXISTS `#__flippingbook_pages`;